/*!
 * Colourfy plugin
 * Author : Freddy Daniel
 *
 * Requirements Jquery v1.5 or later
 * http://owolab.co.nr
 *
 * Copyright 2016
 * Released under the MIT license
 *
 * Date: 10-05-2016
 */

$.fn.greenfy = function() {
    this.css( "color", "green" );
};

$.fn.bluefy = function() {
    this.css( "color", "blue" );
};

$.fn.yellowfy = function() {
    this.css( "color", "yellow" );
};

$.fn.redfy = function() {
    this.css( "color", "red" );
};

$.fn.whitefy = function() {
    this.css( "color", "white" );
};

$.fn.violetfy = function() {
    this.css( "color", "violet" );
};

$.fn.AliceBluefy = function(){
	this.css("color", "#f0f8ff");	
};

$.fn.AntiqueWhitefy = function(){
	this.css("color", "#faebd7");	
};

$.fn.AntiqueWhite1fy = function(){
	this.css("color", "#ffefdb");	
};

$.fn.AntiqueWhite2fy = function(){
	this.css("color", "#eedfcc");	
};

$.fn.AntiqueWhite3fy = function(){
	this.css("color", "#cdc0b0");	
};

$.fn.AntiqueWhite4fy = function(){
	this.css("color", "#8b8378");	
};

$.fn.aquamarine1fy = function(){
	this.css("color", "#7fffd4");	
};

$.fn.aquamarine2fy = function(){
	this.css("color", "#76eec6");	
};

$.fn.aquamarine4fy = function(){
	this.css("color", "#458b74");	
};

$.fn.azure1fy = function(){
	this.css("color", "#f0ffff");	
};

$.fn.azure2fy = function(){
	this.css("color", "#e0eeee");	
};

$.fn.azure3fy = function(){
	this.css("color", "#c1cdcd");	
};

$.fn.azure4fy = function(){
	this.css("color", "#838b8b");	
};

$.fn.beigefy = function(){
	this.css("color", "#f5f5dc");	
};

$.fn.bisque1fy = function(){
	this.css("color", "#ffe4c4");	
};

$.fn.bisque2fy = function(){
	this.css("color", "#eed5b7");	
};

$.fn.bisque3fy = function(){
	this.css("color", "#cdb79e");	
};

$.fn.bisque4fy = function(){
	this.css("color", "#8b7d6b");	
};

$.fn.blackfy = function(){
	this.css("color", "#000000");	
};

$.fn.BlanchedAlmondfy = function(){
	this.css("color", "#ffebcd");	
};

$.fn.blue1fy = function(){
	this.css("color", "#0000ff");	
};

$.fn.blue2fy = function(){
	this.css("color", "#0000ee");	
};

$.fn.blue4fy = function(){
	this.css("color", "#00008b");	
};

$.fn.BlueVioletfy = function(){
	this.css("color", "#8a2be2");	
};

$.fn.brownfy = function(){
	this.css("color", "#a52a2a");	
};

$.fn.brown1fy = function(){
	this.css("color", "#ff4040");	
};

$.fn.brown2fy = function(){
	this.css("color", "#ee3b3b");	
};

$.fn.brown3fy = function(){
	this.css("color", "#cd3333");	
};

$.fn.brown4fy = function(){
	this.css("color", "#8b2323");	
};

$.fn.burlywoodfy = function(){
	this.css("color", "#deb887");	
};

$.fn.burlywood1fy = function(){
	this.css("color", "#ffd39b");	
};

$.fn.burlywood2fy = function(){
	this.css("color", "#eec591");	
};

$.fn.burlywood3fy = function(){
	this.css("color", "#cdaa7d");	
};

$.fn.burlywood4fy = function(){
	this.css("color", "#8b7355");	
};

$.fn.CadetBluefy = function(){
	this.css("color", "#5f9ea0");	
};

$.fn.CadetBlue1fy = function(){
	this.css("color", "#98f5ff");	
};

$.fn.CadetBlue2fy = function(){
	this.css("color", "#8ee5ee");	
};

$.fn.CadetBlue3fy = function(){
	this.css("color", "#7ac5cd");	
};

$.fn.CadetBlue4fy = function(){
	this.css("color", "#53868b");	
};

$.fn.chartreuse1fy = function(){
	this.css("color", "#7fff00");	
};

$.fn.chartreuse2fy = function(){
	this.css("color", "#76ee00");	
};

$.fn.chartreuse3fy = function(){
	this.css("color", "#66cd00");	
};

$.fn.chartreuse4fy = function(){
	this.css("color", "#458b00");	
};

$.fn.chocolatefy = function(){
	this.css("color", "#d2691e");	
};

$.fn.chocolate1fy = function(){
	this.css("color", "#ff7f24");	
};

$.fn.chocolate2fy = function(){
	this.css("color", "#ee7621");	
};

$.fn.chocolate3fy = function(){
	this.css("color", "#cd661d");	
};

$.fn.coralfy = function(){
	this.css("color", "#ff7f50");	
};

$.fn.coral1fy = function(){
	this.css("color", "#ff7256");	
};

$.fn.coral2fy = function(){
	this.css("color", "#ee6a50");	
};

$.fn.coral3fy = function(){
	this.css("color", "#cd5b45");	
};

$.fn.coral4fy = function(){
	this.css("color", "#8b3e2f");	
};

$.fn.CornflowerBluefy = function(){
	this.css("color", "#6495ed");	
};

$.fn.cornsilk1fy = function(){
	this.css("color", "#fff8dc");	
};

$.fn.cornsilk2fy = function(){
	this.css("color", "#eee8cd");	
};

$.fn.cornsilk3fy = function(){
	this.css("color", "#cdc8b1");	
};

$.fn.cornsilk4fy = function(){
	this.css("color", "#8b8878");	
};

$.fn.cyan1fy = function(){
	this.css("color", "#00ffff");	
};

$.fn.cyan2fy = function(){
	this.css("color", "#00eeee");	
};

$.fn.cyan3fy = function(){
	this.css("color", "#00cdcd");	
};

$.fn.cyan4fy = function(){
	this.css("color", "#008b8b");	
};

$.fn.DarkGoldenrodfy = function(){
	this.css("color", "#b8860b");	
};

$.fn.DarkGoldenrod1fy = function(){
	this.css("color", "#ffb90f");	
};

$.fn.DarkGoldenrod2fy = function(){
	this.css("color", "#eead0e");	
};

$.fn.DarkGoldenrod3fy = function(){
	this.css("color", "#cd950c");	
};

$.fn.DarkGoldenrod4fy = function(){
	this.css("color", "#8b6508");	
};

$.fn.DarkGreenfy = function(){
	this.css("color", "#006400");	
};

$.fn.DarkKhakify = function(){
	this.css("color", "#bdb76b");	
};

$.fn.DarkOliveGreenfy = function(){
	this.css("color", "#556b2f");	
};

$.fn.DarkOliveGreen1fy = function(){
	this.css("color", "#caff70");	
};

$.fn.DarkOliveGreen2fy = function(){
	this.css("color", "#bcee68");	
};

$.fn.DarkOliveGreen3fy = function(){
	this.css("color", "#a2cd5a");	
};

$.fn.DarkOliveGreen4fy = function(){
	this.css("color", "#6e8b3d");	
};

$.fn.DarkOrangefy = function(){
	this.css("color", "#ff8c00");	
};

$.fn.DarkOrange1fy = function(){
	this.css("color", "#ff7f00");	
};

$.fn.DarkOrange2fy = function(){
	this.css("color", "#ee7600");	
};

$.fn.DarkOrange3fy = function(){
	this.css("color", "#cd6600");	
};

$.fn.DarkOrange4fy = function(){
	this.css("color", "#8b4500");	
};

$.fn.DarkOrchidfy = function(){
	this.css("color", "#9932cc");	
};

$.fn.DarkOrchid1fy = function(){
	this.css("color", "#bf3eff");	
};

$.fn.DarkOrchid2fy = function(){
	this.css("color", "#b23aee");	
};

$.fn.DarkOrchid3fy = function(){
	this.css("color", "#9a32cd");	
};

$.fn.DarkOrchid4fy = function(){
	this.css("color", "#68228b");	
};

$.fn.DarkSalmonfy = function(){
	this.css("color", "#e9967a");	
};

$.fn.DarkSeaGreenfy = function(){
	this.css("color", "#8fbc8f");	
};

$.fn.DarkSeaGreen1fy = function(){
	this.css("color", "#c1ffc1");	
};

$.fn.DarkSeaGreen2fy = function(){
	this.css("color", "#b4eeb4");	
};

$.fn.DarkSeaGreen3fy = function(){
	this.css("color", "#9bcd9b");	
};

$.fn.DarkSeaGreen4fy = function(){
	this.css("color", "#698b69");	
};

$.fn.DarkSlateBluefy = function(){
	this.css("color", "#483d8b");	
};

$.fn.DarkSlateGrayfy = function(){
	this.css("color", "#2f4f4f");	
};

$.fn.DarkSlateGray1fy = function(){
	this.css("color", "#97ffff");	
};

$.fn.DarkSlateGray2fy = function(){
	this.css("color", "#8deeee");	
};

$.fn.DarkSlateGray3fy = function(){
	this.css("color", "#79cdcd");	
};

$.fn.DarkSlateGray4fy = function(){
	this.css("color", "#528b8b");	
};

$.fn.DarkTurquoisefy = function(){
	this.css("color", "#00ced1");	
};

$.fn.DarkVioletfy = function(){
	this.css("color", "#9400d3");	
};

$.fn.DeepPink1fy = function(){
	this.css("color", "#ff1493");	
};

$.fn.DeepPink2fy = function(){
	this.css("color", "#ee1289");	
};

$.fn.DeepPink3fy = function(){
	this.css("color", "#cd1076");	
};

$.fn.DeepPink4fy = function(){
	this.css("color", "#8b0a50");	
};

$.fn.DeepSkyBlue1fy = function(){
	this.css("color", "#00bfff");	
};

$.fn.DeepSkyBlue2fy = function(){
	this.css("color", "#00b2ee");	
};

$.fn.DeepSkyBlue3fy = function(){
	this.css("color", "#009acd");	
};

$.fn.DeepSkyBlue4fy = function(){
	this.css("color", "#00688b");	
};

$.fn.DimGrayfy = function(){
	this.css("color", "#696969");	
};

$.fn.DodgerBlue1fy = function(){
	this.css("color", "#1e90ff");	
};

$.fn.DodgerBlue2fy = function(){
	this.css("color", "#1c86ee");	
};

$.fn.DodgerBlue3fy = function(){
	this.css("color", "#1874cd");	
};

$.fn.DodgerBlue4fy = function(){
	this.css("color", "#104e8b");	
};

$.fn.firebrickfy = function(){
	this.css("color", "#b22222");	
};

$.fn.firebrick1fy = function(){
	this.css("color", "#ff3030");	
};

$.fn.firebrick2fy = function(){
	this.css("color", "#ee2c2c");	
};

$.fn.firebrick3fy = function(){
	this.css("color", "#cd2626");	
};

$.fn.firebrick4fy = function(){
	this.css("color", "#8b1a1a");	
};

$.fn.FloralWhitefy = function(){
	this.css("color", "#fffaf0");	
};

$.fn.ForestGreenfy = function(){
	this.css("color", "#228b22");	
};

$.fn.gainsborofy = function(){
	this.css("color", "#dcdcdc");	
};

$.fn.GhostWhitefy = function(){
	this.css("color", "#f8f8ff");	
};

$.fn.gold1fy = function(){
	this.css("color", "#ffd700");	
};

$.fn.gold2fy = function(){
	this.css("color", "#eec900");	
};

$.fn.gold3fy = function(){
	this.css("color", "#cdad00");	
};

$.fn.gold4fy = function(){
	this.css("color", "#8b7500");	
};

$.fn.goldenrodfy = function(){
	this.css("color", "#daa520");	
};

$.fn.goldenrod1fy = function(){
	this.css("color", "#ffc125");	
};

$.fn.goldenrod2fy = function(){
	this.css("color", "#eeb422");	
};

$.fn.goldenrod3fy = function(){
	this.css("color", "#cd9b1d");	
};

$.fn.goldenrod4fy = function(){
	this.css("color", "#8b6914");	
};
	
$.fn.grayfy = function(){
	this.css("color", "#bebebe");	
};

$.fn.gray1fy = function(){
	this.css("color", "#030303");	
};

$.fn.gray10fy = function(){
	this.css("color", "#1a1a1a");	
};

$.fn.gray11fy = function(){
	this.css("color", "#1c1c1c");	
};

$.fn.gray12fy = function(){
	this.css("color", "#1f1f1f");	
};

$.fn.gray13fy = function(){
	this.css("color", "#212121");	
};

$.fn.gray14fy = function(){
	this.css("color", "#242424");	
};

$.fn.gray15fy = function(){
	this.css("color", "#262626");	
};

$.fn.gray16fy = function(){
	this.css("color", "#292929");	
};

$.fn.gray17fy = function(){
	this.css("color", "#2b2b2b");	
};

$.fn.gray18fy = function(){
	this.css("color", "#2e2e2e");	
};

$.fn.gray19fy = function(){
	this.css("color", "#303030");	
};

$.fn.gray2fy = function(){
	this.css("color", "#050505");	
};

$.fn.gray20fy = function(){
	this.css("color", "#333333");	
};

$.fn.gray21fy = function(){
	this.css("color", "#363636");	
};

$.fn.gray22fy = function(){
	this.css("color", "#383838");	
};

$.fn.gray23fy = function(){
	this.css("color", "#3b3b3b");	
};

$.fn.gray24fy = function(){
	this.css("color", "#3d3d3d");	
};

$.fn.gray25fy = function(){
	this.css("color", "#404040");	
};

$.fn.gray26fy = function(){
	this.css("color", "#424242");	
};

$.fn.gray27fy = function(){
	this.css("color", "#454545");	
};

$.fn.gray28fy = function(){
	this.css("color", "#474747");	
};

$.fn.gray29fy = function(){
	this.css("color", "#4a4a4a");	
};

$.fn.gray3fy = function(){
	this.css("color", "#080808");	
};

$.fn.gray30fy = function(){
	this.css("color", "#4d4d4d");	
};

$.fn.gray31fy = function(){
	this.css("color", "#4f4f4f");	
};

$.fn.gray32fy = function(){
	this.css("color", "#525252");	
};

$.fn.gray33fy = function(){
	this.css("color", "#545454");	
};

$.fn.gray34fy = function(){
	this.css("color", "#575757");	
};

$.fn.gray35fy = function(){
	this.css("color", "#595959");	
};

$.fn.gray36fy = function(){
	this.css("color", "#5c5c5c");	
};

$.fn.gray37fy = function(){
	this.css("color", "#5e5e5e");	
};

$.fn.gray38fy = function(){
	this.css("color", "#616161");	
};

$.fn.gray39fy = function(){
	this.css("color", "#636363");	
};

$.fn.gray4fy = function(){
	this.css("color", "#0a0a0a");	
};

$.fn.gray40fy = function(){
	this.css("color", "#666666");	
};

$.fn.gray41fy = function(){
	this.css("color", "#696969");	
};

$.fn.gray42fy = function(){
	this.css("color", "#6b6b6b");	
};

$.fn.gray43fy = function(){
	this.css("color", "#6e6e6e");	
};

$.fn.gray44fy = function(){
	this.css("color", "#707070");	
};

$.fn.gray45fy = function(){
	this.css("color", "#737373");	
};

$.fn.gray46fy = function(){
	this.css("color", "#757575");	
};

$.fn.gray47fy = function(){
	this.css("color", "#787878");	
};

$.fn.gray48fy = function(){
	this.css("color", "#7a7a7a");	
};

$.fn.gray49fy = function(){
	this.css("color", "#7d7d7d");	
};

$.fn.gray5fy = function(){
	this.css("color", "#0d0d0d");	
};

$.fn.gray50fy = function(){
	this.css("color", "#7f7f7f");	
};

$.fn.gray51fy = function(){
	this.css("color", "#828282");	
};

$.fn.gray52fy = function(){
	this.css("color", "#858585");	
};

$.fn.gray53fy = function(){
	this.css("color", "#878787");	
};

$.fn.gray54fy = function(){
	this.css("color", "#8a8a8a");	
};

$.fn.gray55fy = function(){
	this.css("color", "#8c8c8c");	
};

$.fn.gray56fy = function(){
	this.css("color", "#8f8f8f");	
};

$.fn.gray57fy = function(){
	this.css("color", "#919191");	
};

$.fn.gray58fy = function(){
	this.css("color", "#949494");	
};

$.fn.gray59fy = function(){
	this.css("color", "#969696");	
};

$.fn.gray6fy = function(){
	this.css("color", "#0f0f0f");	
};

$.fn.gray60fy = function(){
	this.css("color", "#999999");	
};

$.fn.gray61fy = function(){
	this.css("color", "#9c9c9c");	
};

$.fn.gray62fy = function(){
	this.css("color", "#9e9e9e");	
};

$.fn.gray63fy = function(){
	this.css("color", "#a1a1a1");	
};

$.fn.gray64fy = function(){
	this.css("color", "#a3a3a3");	
};

$.fn.gray65fy = function(){
	this.css("color", "#a6a6a6");	
};

$.fn.gray66fy = function(){
	this.css("color", "#a8a8a8");	
};

$.fn.gray67fy = function(){
	this.css("color", "#ababab");	
};

$.fn.gray68fy = function(){
	this.css("color", "#adadad");	
};

$.fn.gray69fy = function(){
	this.css("color", "#b0b0b0");	
};

$.fn.gray7fy = function(){
	this.css("color", "#121212");	
};

$.fn.gray70fy = function(){
	this.css("color", "#b3b3b3");	
};

$.fn.gray71fy = function(){
	this.css("color", "#b5b5b5");	
};

$.fn.gray72fy = function(){
	this.css("color", "#b8b8b8");	
};

$.fn.gray73fy = function(){
	this.css("color", "#bababa");	
};

$.fn.gray74fy = function(){
	this.css("color", "#bdbdbd");	
};

$.fn.gray75fy = function(){
	this.css("color", "#bfbfbf");	
};

$.fn.gray76fy = function(){
	this.css("color", "#c2c2c2");	
};

$.fn.gray77fy = function(){
	this.css("color", "#c4c4c4");	
};

$.fn.gray78fy = function(){
	this.css("color", "#c7c7c7");	
};

$.fn.gray79fy = function(){
	this.css("color", "#c9c9c9");	
};

$.fn.gray8fy = function(){
	this.css("color", "#141414");	
};

$.fn.gray80fy = function(){
	this.css("color", "#cccccc");	
};

$.fn.gray81fy = function(){
	this.css("color", "#cfcfcf");	
};

$.fn.gray82fy = function(){
	this.css("color", "#d1d1d1");	
};

$.fn.gray83fy = function(){
	this.css("color", "#d4d4d4");	
};

$.fn.gray84fy = function(){
	this.css("color", "#d6d6d6");	
};

$.fn.gray85fy = function(){
	this.css("color", "#d9d9d9");	
};

$.fn.gray86fy = function(){
	this.css("color", "#dbdbdb");	
};

$.fn.gray87fy = function(){
	this.css("color", "#dedede");	
};

$.fn.gray88fy = function(){
	this.css("color", "#e0e0e0");	
};

$.fn.gray89fy = function(){
	this.css("color", "#e3e3e3");	
};

$.fn.gray9fy = function(){
	this.css("color", "#171717");	
};

$.fn.gray90fy = function(){
	this.css("color", "#e5e5e5");	
};

$.fn.gray91fy = function(){
	this.css("color", "#e8e8e8");	
};

$.fn.gray92fy = function(){
	this.css("color", "#ebebeb");	
};

$.fn.gray93fy = function(){
	this.css("color", "#ededed");	
};

$.fn.gray94fy = function(){
	this.css("color", "#f0f0f0");	
};

$.fn.gray95fy = function(){
	this.css("color", "#f2f2f2");	
};

$.fn.gray97fy = function(){
	this.css("color", "#f7f7f7");	
};

$.fn.gray98fy = function(){
	this.css("color", "#fafafa");	
};

$.fn.gray99fy = function(){
	this.css("color", "#fcfcfc");	
};

$.fn.green1fy = function(){
	this.css("color", "#00ff00");	
};

$.fn.green2fy = function(){
	this.css("color", "#00ee00");	
};

$.fn.green3fy = function(){
	this.css("color", "#00cd00");	
};

$.fn.green4fy = function(){
	this.css("color", "#008b00");	
};

$.fn.GreenYellowfy = function(){
	this.css("color", "#adff2f");	
};

$.fn.honeydew1fy = function(){
	this.css("color", "#f0fff0");	
};

$.fn.honeydew2fy = function(){
	this.css("color", "#e0eee0");	
};

$.fn.honeydew3fy = function(){
	this.css("color", "#c1cdc1");	
};

$.fn.honeydew4fy = function(){
	this.css("color", "#838b83");	
};

$.fn.HotPinkfy = function(){
	this.css("color", "#ff69b4");	
};

$.fn.HotPink1fy = function(){
	this.css("color", "#ff6eb4");	
};

$.fn.HotPink2fy = function(){
	this.css("color", "#ee6aa7");	
};

$.fn.HotPink3fy = function(){
	this.css("color", "#cd6090");	
};

$.fn.HotPink4fy = function(){
	this.css("color", "#8b3a62");	
};

$.fn.IndianRedfy = function(){
	this.css("color", "#cd5c5c");	
};

$.fn.IndianRed1fy = function(){
	this.css("color", "#ff6a6a");	
};

$.fn.IndianRed2fy = function(){
	this.css("color", "#ee6363");	
};

$.fn.IndianRed3fy = function(){
	this.css("color", "#cd5555");	
};

$.fn.IndianRed4fy = function(){
	this.css("color", "#8b3a3a");	
};

$.fn.ivory1fy = function(){
	this.css("color", "#fffff0");	
};

$.fn.ivory2fy = function(){
	this.css("color", "#eeeee0");	
};

$.fn.ivory3fy = function(){
	this.css("color", "#cdcdc1");	
};

$.fn.ivory4fy = function(){
	this.css("color", "#8b8b83");	
};

$.fn.khakify = function(){
	this.css("color", "#f0e68c");	
};

$.fn.khaki1fy = function(){
	this.css("color", "#fff68f");	
};

$.fn.khaki2fy = function(){
	this.css("color", "#eee685");	
};

$.fn.khaki3fy = function(){
	this.css("color", "#cdc673");	
};

$.fn.khaki4fy = function(){
	this.css("color", "#8b864e");	
};

$.fn.lavenderfy = function(){
	this.css("color", "#e6e6fa");	
};

$.fn.LavenderBlush1fy = function(){
	this.css("color", "#fff0f5");	
};

$.fn.LavenderBlush2fy = function(){
	this.css("color", "#eee0e5");	
};

$.fn.LavenderBlush3fy = function(){
	this.css("color", "#cdc1c5");	
};

$.fn.LavenderBlush4fy = function(){
	this.css("color", "#8b8386");	
};

$.fn.LawnGreenfy = function(){
	this.css("color", "#7cfc00");	
};

$.fn.LemonChiffon1fy = function(){
	this.css("color", "#fffacd");	
};

$.fn.LemonChiffon2fy = function(){
	this.css("color", "#eee9bf");	
};

$.fn.LemonChiffon3fy = function(){
	this.css("color", "#cdc9a5");	
};

$.fn.LemonChiffon4fy = function(){
	this.css("color", "#8b8970");	
};

$.fn.lightfy = function(){
	this.css("color", "#eedd82");	
};

$.fn.LightBluefy = function(){
	this.css("color", "#add8e6");	
};

$.fn.LightBlue1fy = function(){
	this.css("color", "#bfefff");	
};

$.fn.LightBlue2fy = function(){
	this.css("color", "#b2dfee");	
};

$.fn.LightBlue3fy = function(){
	this.css("color", "#9ac0cd");	
};

$.fn.LightBlue4fy = function(){
	this.css("color", "#68838b");	
};

$.fn.LightCoralfy = function(){
	this.css("color", "#f08080");	
};

$.fn.LightCyan1fy = function(){
	this.css("color", "#e0ffff");	
};

$.fn.LightCyan2fy = function(){
	this.css("color", "#d1eeee");	
};

$.fn.LightCyan3fy = function(){
	this.css("color", "#b4cdcd");	
};

$.fn.LightCyan4fy = function(){
	this.css("color", "#7a8b8b");	
};

$.fn.LightGoldenrod1fy = function(){
	this.css("color", "#ffec8b");	
};

$.fn.LightGoldenrod2fy = function(){
	this.css("color", "#eedc82");	
};

$.fn.LightGoldenrod3fy = function(){
	this.css("color", "#cdbe70");	
};

$.fn.LightGoldenrod4fy = function(){
	this.css("color", "#8b814c");	
};

$.fn.LightGoldenrodYellowfy = function(){
	this.css("color", "#fafad2");	
};

$.fn.LightGrayfy = function(){
	this.css("color", "#d3d3d3");	
};

$.fn.LightPinkfy = function(){
	this.css("color", "#ffb6c1");	
};

$.fn.LightPink1fy = function(){
	this.css("color", "#ffaeb9");	
};

$.fn.LightPink2fy = function(){
	this.css("color", "#eea2ad");	
};

$.fn.LightPink3fy = function(){
	this.css("color", "#cd8c95");	
};

$.fn.LightPink4fy = function(){
	this.css("color", "#8b5f65");	
};

$.fn.LightSalmon1fy = function(){
	this.css("color", "#ffa07a");	
};

$.fn.LightSalmon2fy = function(){
	this.css("color", "#ee9572");	
};

$.fn.LightSalmon3fy = function(){
	this.css("color", "#cd8162");	
};

$.fn.LightSalmon4fy = function(){
	this.css("color", "#8b5742");	
};

$.fn.LightSeaGreenfy = function(){
	this.css("color", "#20b2aa");	
};

$.fn.LightSkyBluefy = function(){
	this.css("color", "#87cefa");	
};

$.fn.LightSkyBlue1fy = function(){
	this.css("color", "#b0e2ff");	
};

$.fn.LightSkyBlue2fy = function(){
	this.css("color", "#a4d3ee");	
};

$.fn.LightSkyBlue3fy = function(){
	this.css("color", "#8db6cd");	
};

$.fn.LightSkyBlue4fy = function(){
	this.css("color", "#607b8b");	
};

$.fn.LightSlateBluefy = function(){
	this.css("color", "#8470ff");	
};

$.fn.LightSlateGrayfy = function(){
	this.css("color", "#778899");	
};

$.fn.LightSteelBluefy = function(){
	this.css("color", "#b0c4de");	
};

$.fn.LightSteelBlue1fy = function(){
	this.css("color", "#cae1ff");	
};

$.fn.LightSteelBlue2fy = function(){
	this.css("color", "#bcd2ee");	
};

$.fn.LightSteelBlue3fy = function(){
	this.css("color", "#a2b5cd");	
};

$.fn.LightSteelBlue4fy = function(){
	this.css("color", "#6e7b8b");	
};

$.fn.LightYellow1fy = function(){
	this.css("color", "#ffffe0");	
};

$.fn.LightYellow2fy = function(){
	this.css("color", "#eeeed1");	
};

$.fn.LightYellow3fy = function(){
	this.css("color", "#cdcdb4");	
};

$.fn.LightYellow4fy = function(){
	this.css("color", "#8b8b7a");	
};

$.fn.LimeGreenfy = function(){
	this.css("color", "#32cd32");	
};

$.fn.linenfy = function(){
	this.css("color", "#faf0e6");	
};

$.fn.magentafy = function(){
	this.css("color", "#ff00ff");	
};

$.fn.magenta2fy = function(){
	this.css("color", "#ee00ee");	
};

$.fn.magenta3fy = function(){
	this.css("color", "#cd00cd");	
};

$.fn.magenta4fy = function(){
	this.css("color", "#8b008b");	
};

$.fn.maroonfy = function(){
	this.css("color", "#b03060");	
};

$.fn.maroon1fy = function(){
	this.css("color", "#ff34b3");	
};

$.fn.maroon2fy = function(){
	this.css("color", "#ee30a7");	
};

$.fn.maroon3fy = function(){
	this.css("color", "#cd2990");	
};

$.fn.maroon4fy = function(){
	this.css("color", "#8b1c62");	
};

$.fn.mediumfy = function(){
	this.css("color", "#66cdaa");	
};

$.fn.MediumAquamarinefy = function(){
	this.css("color", "#66cdaa");	
};

$.fn.MediumBluefy = function(){
	this.css("color", "#0000cd");	
};

$.fn.MediumOrchidfy = function(){
	this.css("color", "#ba55d3");	
};

$.fn.MediumOrchid1fy = function(){
	this.css("color", "#e066ff");	
};

$.fn.MediumOrchid2fy = function(){
	this.css("color", "#d15fee");	
};

$.fn.MediumOrchid3fy = function(){
	this.css("color", "#b452cd");	
};

$.fn.MediumOrchid4fy = function(){
	this.css("color", "#7a378b");	
};

$.fn.MediumPurplefy = function(){
	this.css("color", "#9370db");	
};

$.fn.MediumPurple1fy = function(){
	this.css("color", "#ab82ff");	
};

$.fn.MediumPurple2fy = function(){
	this.css("color", "#9f79ee");	
};

$.fn.MediumPurple3fy = function(){
	this.css("color", "#8968cd");	
};

$.fn.MediumPurple4fy = function(){
	this.css("color", "#5d478b");	
};

$.fn.MediumSeaGreenfy = function(){
	this.css("color", "#3cb371");	
};

$.fn.MediumSlateBluefy = function(){
	this.css("color", "#7b68ee");	
};

$.fn.MediumSpringGreenfy = function(){
	this.css("color", "#00fa9a");	
};

$.fn.MediumTurquoisefy = function(){
	this.css("color", "#48d1cc");	
};

$.fn.MediumVioletRedfy = function(){
	this.css("color", "#c71585");	
};

$.fn.MidnightBluefy = function(){
	this.css("color", "#191970");	
};

$.fn.MintCreamfy = function(){
	this.css("color", "#f5fffa");	
};

$.fn.MistyRose1fy = function(){
	this.css("color", "#ffe4e1");	
};

$.fn.MistyRose2fy = function(){
	this.css("color", "#eed5d2");	
};

$.fn.MistyRose3fy = function(){
	this.css("color", "#cdb7b5");	
};

$.fn.MistyRose4fy = function(){
	this.css("color", "#8b7d7b");	
};

$.fn.moccasinfy = function(){
	this.css("color", "#ffe4b5");	
};

$.fn.NavajoWhite1fy = function(){
	this.css("color", "#ffdead");	
};

$.fn.NavajoWhite2fy = function(){
	this.css("color", "#eecfa1");	
};

$.fn.NavajoWhite3fy = function(){
	this.css("color", "#cdb38b");	
};

$.fn.NavajoWhite4fy = function(){
	this.css("color", "#8b795e");	
};

$.fn.NavyBluefy = function(){
	this.css("color", "#000080");	
};

$.fn.OldLacefy = function(){
	this.css("color", "#fdf5e6");	
};

$.fn.OliveDrabfy = function(){
	this.css("color", "#6b8e23");	
};

$.fn.OliveDrab1fy = function(){
	this.css("color", "#c0ff3e");	
};

$.fn.OliveDrab2fy = function(){
	this.css("color", "#b3ee3a");	
};

$.fn.OliveDrab4fy = function(){
	this.css("color", "#698b22");	
};

$.fn.orange1fy = function(){
	this.css("color", "#ffa500");	
};

$.fn.orange2fy = function(){
	this.css("color", "#ee9a00");	
};

$.fn.orange3fy = function(){
	this.css("color", "#cd8500");	
};

$.fn.orange4fy = function(){
	this.css("color", "#8b5a00");	
};

$.fn.OrangeRed1fy = function(){
	this.css("color", "#ff4500");	
};

$.fn.OrangeRed2fy = function(){
	this.css("color", "#ee4000");	
};

$.fn.OrangeRed3fy = function(){
	this.css("color", "#cd3700");	
};

$.fn.OrangeRed4fy = function(){
	this.css("color", "#8b2500");	
};

$.fn.orchidfy = function(){
	this.css("color", "#da70d6");	
};

$.fn.orchid1fy = function(){
	this.css("color", "#ff83fa");	
};

$.fn.orchid2fy = function(){
	this.css("color", "#ee7ae9");	
};

$.fn.orchid3fy = function(){
	this.css("color", "#cd69c9");	
};

$.fn.orchid4fy = function(){
	this.css("color", "#8b4789");	
};		

$.fn.palefy = function(){
	this.css("color", "#db7093");	
};

$.fn.PaleGoldenrodfy = function(){
	this.css("color", "#eee8aa");	
};

$.fn.PaleGreenfy = function(){
	this.css("color", "#98fb98");	
};

$.fn.PaleGreen1fy = function(){
	this.css("color", "#9aff9a");	
};

$.fn.PaleGreen2fy = function(){
	this.css("color", "#90ee90");	
};

$.fn.PaleGreen3fy = function(){
	this.css("color", "#7ccd7c");	
};

$.fn.PaleGreen4fy = function(){
	this.css("color", "#548b54");	
};

$.fn.PaleTurquoisefy = function(){
	this.css("color", "#afeeee");	
};

$.fn.PaleTurquoise1fy = function(){
	this.css("color", "#bbffff");	
};

$.fn.PaleTurquoise2fy = function(){
	this.css("color", "#aeeeee");	
};

$.fn.PaleTurquoise3fy = function(){
	this.css("color", "#96cdcd");	
};

$.fn.PaleTurquoise4fy = function(){
	this.css("color", "#668b8b");	
};

$.fn.PaleVioletRedfy = function(){
	this.css("color", "#db7093");	
};

$.fn.PaleVioletRed1fy = function(){
	this.css("color", "#ff82ab");	
};

$.fn.PaleVioletRed2fy = function(){
	this.css("color", "#ee799f");	
};

$.fn.PaleVioletRed3fy = function(){
	this.css("color", "#cd6889");	
};

$.fn.PaleVioletRed4fy = function(){
	this.css("color", "#8b475d");	
};

$.fn.PapayaWhipfy = function(){
	this.css("color", "#ffefd5");	
};

$.fn.PeachPuff1fy = function(){
	this.css("color", "#ffdab9");	
};

$.fn.PeachPuff2fy = function(){
	this.css("color", "#eecbad");	
};

$.fn.PeachPuff3fy = function(){
	this.css("color", "#cdaf95");	
};

$.fn.PeachPuff4fy = function(){
	this.css("color", "#8b7765");	
};

$.fn.pinkfy = function(){
	this.css("color", "#ffc0cb");	
};

$.fn.pink1fy = function(){
	this.css("color", "#ffb5c5");	
};

$.fn.pink2fy = function(){
	this.css("color", "#eea9b8");	
};

$.fn.pink3fy = function(){
	this.css("color", "#cd919e");	
};

$.fn.pink4fy = function(){
	this.css("color", "#8b636c");	
};

$.fn.plumfy = function(){
	this.css("color", "#dda0dd");	
};

$.fn.plum1fy = function(){
	this.css("color", "#ffbbff");	
};

$.fn.plum2fy = function(){
	this.css("color", "#eeaeee");	
};

$.fn.plum3fy = function(){
	this.css("color", "#cd96cd");	
};

$.fn.plum4fy = function(){
	this.css("color", "#8b668b");	
};

$.fn.PowderBluefy = function(){
	this.css("color", "#b0e0e6");	
};

$.fn.purplefy = function(){
	this.css("color", "#a020f0");	
};

$.fn.rebeccapurplefy = function(){
	this.css("color", "#663399");	
};

$.fn.purple1fy = function(){
	this.css("color", "#9b30ff");	
};

$.fn.purple2fy = function(){
	this.css("color", "#912cee");	
};

$.fn.purple3fy = function(){
	this.css("color", "#7d26cd");	
};

$.fn.purple4fy = function(){
	this.css("color", "#551a8b");	
};

$.fn.red1fy = function(){
	this.css("color", "#ff0000");	
};

$.fn.red2fy = function(){
	this.css("color", "#ee0000");	
};

$.fn.red3fy = function(){
	this.css("color", "#cd0000");	
};

$.fn.red4fy = function(){
	this.css("color", "#8b0000");	
};

$.fn.RosyBrownfy = function(){
	this.css("color", "#bc8f8f");	
};

$.fn.RosyBrown1fy = function(){
	this.css("color", "#ffc1c1");	
};

$.fn.RosyBrown2fy = function(){
	this.css("color", "#eeb4b4");	
};

$.fn.RosyBrown3fy = function(){
	this.css("color", "#cd9b9b");	
};

$.fn.RosyBrown4fy = function(){
	this.css("color", "#8b6969");	
};

$.fn.RoyalBluefy = function(){
	this.css("color", "#4169e1");	
};

$.fn.RoyalBlue1fy = function(){
	this.css("color", "#4876ff");	
};

$.fn.RoyalBlue2fy = function(){
	this.css("color", "#436eee");	
};

$.fn.RoyalBlue3fy = function(){
	this.css("color", "#3a5fcd");	
};

$.fn.RoyalBlue4fy = function(){
	this.css("color", "#27408b");	
};

$.fn.SaddleBrownfy = function(){
	this.css("color", "#8b4513");	
};

$.fn.salmonfy = function(){
	this.css("color", "#fa8072");	
};

$.fn.salmon1fy = function(){
	this.css("color", "#ff8c69");	
};

$.fn.salmon2fy = function(){
	this.css("color", "#ee8262");	
};

$.fn.salmon3fy = function(){
	this.css("color", "#cd7054");	
};

$.fn.salmon4fy = function(){
	this.css("color", "#8b4c39");	
};

$.fn.SandyBrownfy = function(){
	this.css("color", "#f4a460");	
};

$.fn.SeaGreen1fy = function(){
	this.css("color", "#54ff9f");	
};

$.fn.SeaGreen2fy = function(){
	this.css("color", "#4eee94");	
};

$.fn.SeaGreen3fy = function(){
	this.css("color", "#43cd80");	
};

$.fn.SeaGreen4fy = function(){
	this.css("color", "#2e8b57");	
};

$.fn.seashell1fy = function(){
	this.css("color", "#fff5ee");	
};

$.fn.seashell2fy = function(){
	this.css("color", "#eee5de");	
};

$.fn.seashell3fy = function(){
	this.css("color", "#cdc5bf");	
};

$.fn.seashell4fy = function(){
	this.css("color", "#8b8682");	
};

$.fn.siennafy = function(){
	this.css("color", "#a0522d");	
};

$.fn.sienna1fy = function(){
	this.css("color", "#ff8247");	
};

$.fn.sienna2fy = function(){
	this.css("color", "#ee7942");	
};

$.fn.sienna3fy = function(){
	this.css("color", "#cd6839");	
};

$.fn.sienna4fy = function(){
	this.css("color", "#8b4726");	
};

$.fn.SkyBluefy = function(){
	this.css("color", "#87ceeb");	
};

$.fn.SkyBlue1fy = function(){
	this.css("color", "#87ceff");	
};

$.fn.SkyBlue2fy = function(){
	this.css("color", "#7ec0ee");	
};

$.fn.SkyBlue3fy = function(){
	this.css("color", "#6ca6cd");	
};

$.fn.SkyBlue4fy = function(){
	this.css("color", "#4a708b");	
};

$.fn.SlateBluefy = function(){
	this.css("color", "#6a5acd");	
};

$.fn.SlateBlue1fy = function(){
	this.css("color", "#836fff");	
};

$.fn.SlateBlue2fy = function(){
	this.css("color", "#7a67ee");	
};

$.fn.SlateBlue3fy = function(){
	this.css("color", "#6959cd");	
};

$.fn.SlateBlue4fy = function(){
	this.css("color", "#473c8b");	
};

$.fn.SlateGrayfy = function(){
	this.css("color", "#708090");	
};

$.fn.SlateGray1fy = function(){
	this.css("color", "#c6e2ff");	
};

$.fn.SlateGray2fy = function(){
	this.css("color", "#b9d3ee");	
};

$.fn.SlateGray3fy = function(){
	this.css("color", "#9fb6cd");	
};

$.fn.SlateGray4fy = function(){
	this.css("color", "#6c7b8b");	
};

$.fn.snow1fy = function(){
	this.css("color", "#fffafa");	
};

$.fn.snow2fy = function(){
	this.css("color", "#eee9e9");	
};

$.fn.snow3fy = function(){
	this.css("color", "#cdc9c9");	
};

$.fn.snow4fy = function(){
	this.css("color", "#8b8989");	
};

$.fn.SpringGreen1fy = function(){
	this.css("color", "#00ff7f");	
};

$.fn.SpringGreen2fy = function(){
	this.css("color", "#00ee76");	
};

$.fn.SpringGreen3fy = function(){
	this.css("color", "#00cd66");	
};

$.fn.SpringGreen4fy = function(){
	this.css("color", "#008b45");	
};

$.fn.SteelBluefy = function(){
	this.css("color", "#4682b4");	
};

$.fn.SteelBlue1fy = function(){
	this.css("color", "#63b8ff");	
};

$.fn.SteelBlue2fy = function(){
	this.css("color", "#5cacee");	
};

$.fn.SteelBlue3fy = function(){
	this.css("color", "#4f94cd");	
};

$.fn.SteelBlue4fy = function(){
	this.css("color", "#36648b");	
};

$.fn.tanfy = function(){
	this.css("color", "#d2b48c");	
};

$.fn.tan1fy = function(){
	this.css("color", "#ffa54f");	
};

$.fn.tan2fy = function(){
	this.css("color", "#ee9a49");	
};

$.fn.tan3fy = function(){
	this.css("color", "#cd853f");	
};

$.fn.tan4fy = function(){
	this.css("color", "#8b5a2b");	
};

$.fn.thistlefy = function(){
	this.css("color", "#d8bfd8");	
};

$.fn.thistle1fy = function(){
	this.css("color", "#ffe1ff");	
};

$.fn.thistle2fy = function(){
	this.css("color", "#eed2ee");	
};

$.fn.thistle3fy = function(){
	this.css("color", "#cdb5cd");	
};

$.fn.thistle4fy = function(){
	this.css("color", "#8b7b8b");	
};

$.fn.tomato1fy = function(){
	this.css("color", "#ff6347");	
};

$.fn.tomato2fy = function(){
	this.css("color", "#ee5c42");	
};

$.fn.tomato3fy = function(){
	this.css("color", "#cd4f39");	
};

$.fn.tomato4fy = function(){
	this.css("color", "#8b3626");	
};

$.fn.turquoisefy = function(){
	this.css("color", "#40e0d0");	
};

$.fn.turquoise1fy = function(){
	this.css("color", "#00f5ff");	
};

$.fn.turquoise2fy = function(){
	this.css("color", "#00e5ee");	
};

$.fn.turquoise3fy = function(){
	this.css("color", "#00c5cd");	
};

$.fn.turquoise4fy = function(){
	this.css("color", "#00868b");	
};

$.fn.VioletRedfy = function(){
	this.css("color", "#d02090");	
};

$.fn.VioletRed1fy = function(){
	this.css("color", "#ff3e96");	
};

$.fn.VioletRed2fy = function(){
	this.css("color", "#ee3a8c");	
};

$.fn.VioletRed3fy = function(){
	this.css("color", "#cd3278");	
};

$.fn.VioletRed4fy = function(){
	this.css("color", "#8b2252");	
};

$.fn.wheatfy = function(){
	this.css("color", "#f5deb3");	
};

$.fn.wheat1fy = function(){
	this.css("color", "#ffe7ba");	
};

$.fn.wheat2fy = function(){
	this.css("color", "#eed8ae");	
};

$.fn.wheat3fy = function(){
	this.css("color", "#cdba96");	
};

$.fn.wheat4fy = function(){
	this.css("color", "#8b7e66");	
};

$.fn.WhiteSmokefy = function(){
	this.css("color", "#f5f5f5");	
};

$.fn.yellow1fy = function(){
	this.css("color", "#ffff00");	
};

$.fn.yellow2fy = function(){
	this.css("color", "#eeee00");	
};

$.fn.yellow3fy = function(){
	this.css("color", "#cdcd00");	
};

$.fn.yellow4fy = function(){
	this.css("color", "#8b8b00");	
};

$.fn.YellowGreenfy = function(){
	this.css("color", "#9acd32");	
};

/****************************************
******************END********************
*****************************************/